<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Test Jezelf 2 - Contact</title>
    <link rel="stylesheet" type="text/css" href="reset.css">
    <link rel="stylesheet" type="text/css" href="screen.css">
    <link href="https://fonts.googleapis.com/css?family=Oswald:300" rel="stylesheet">
</head>
<?php include "nav.inc.php"?>
<body>
</body>
<?php include "footer.inc.php"?>
</html>