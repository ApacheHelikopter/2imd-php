<?php 

    if($todo["tijdsduur"]=="2h"){
        echo "test";
    }

?>